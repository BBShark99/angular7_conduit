export default class Blog {
    title: String;
    description: String;
    body: String;
}